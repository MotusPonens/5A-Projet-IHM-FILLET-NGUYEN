FILLET Louis-Edmond
NGUYEN Nathaniel


----------------- Pour lancer Notre application ----------------------

Versions :

NetBeans IDE 7.3.1
Java 1.7
Apache Tomcat 7.0.34.0

--------------------

- Ouvrir le projet avec Netbeans

- Deployer l'application sur Tomcat